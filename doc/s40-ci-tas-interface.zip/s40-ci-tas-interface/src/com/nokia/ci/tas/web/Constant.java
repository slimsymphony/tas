package com.nokia.ci.tas.web;

/**
 * Keeper of all constant values used in Test Automation Service Interface components.
 */
public class Constant {
    /**
     * Time constant of 1 thousandth of a second.
     */
    public static final long MILLISECOND = 1L;

    /**
     * Time constant of 1 hundredth of a second in milliseconds.
     */
    public static final long CENTISECOND = 10L;

    /**
     * Time constant of 1 tenth of a second in milliseconds.
     */
    public static final long DECISECOND = 100L;

    /**
     * Time constant of 1 second in milliseconds.
     */
    public static final long ONE_SECOND = 1000L;

    /**
     * Time constant of 5 seconds in milliseconds.
     */
    public static final long FIVE_SECONDS = 5000L;

    /**
     * Time constant of 10 seconds in milliseconds.
     */
    public static final long TEN_SECONDS = 10000L;

    /**
     * Time constant of 15 seconds in milliseconds.
     */
    public static final long FIFTEEN_SECONDS = 15000L;

    /**
     * Time constant of 30 seconds in milliseconds.
     */
    public static final long THIRTY_SECONDS = 30000L;

    /**
     * Time constant of 1 minute in milliseconds.
     */
    public static final long ONE_MINUTE = 60000L;

    /**
     * Time constant of 2 minutes in milliseconds.
     */
    public static final long TWO_MINUTES = 120000L;

    /**
     * Time constant of 3 minutes in milliseconds.
     */
    public static final long THREE_MINUTES = 180000L;

    /**
     * Time constant of 5 minutes in milliseconds.
     */
    public static final long FIVE_MINUTES = 300000L;

    /**
     * Time constant of 10 minutes in milliseconds.
     */
    public static final long TEN_MINUTES = 600000L;

    /**
     * Time constant of 15 minutes in milliseconds.
     */
    public static final long FIFTEEN_MINUTES = 900000L;

    /**
     * Time constant of 1 hour in milliseconds.
     */
    public static final long ONE_HOUR = 3600000L;

    /**
     * Time constant of 1 day or 24 hours in milliseconds.
     */
    public static final long ONE_DAY = 86400000L;

    /**
     * Default buffer size to be used in networking and file handling.
     */
    public static final int DEFAULT_BUFFER_SIZE = 4096;

    /**
     * A minimal timeout for actual execution of the test on a test node.
     */
    public static final long MINIMAL_TIMEOUT_FOR_TEST_EXECUTION = FIVE_MINUTES;

    /**
     * Name of command line parameter for specifying a hostname of the Test Automation Service Interface.
     */
    public static final String TEST_AUTOMATION_SERVICE_INTERFACE_HOSTNAME_ARGUMENT = "TestAutomationServiceInterfaceHostname";

    /**
     * Name of command line parameter for specifying a port number used by Test Automation Service Interface for incoming connections.
     */
    public static final String TEST_AUTOMATION_SERVICE_INTERFACE_PORT_NUMBER_ARGUMENT = "TestAutomationServiceInterfacePortNumber";

    /**
     * Default port number for the Test Automation Service Interface.
     */
    public static final int TEST_AUTOMATION_SERVICE_INTERFACE_DEFAULT_PORT_NUMBER = 8181;

    /**
     * Name of command line parameter for specifying a description for the Test Automation Service Interface.
     */
    public static final String TEST_AUTOMATION_SERVICE_INTERFACE_DESCRIPTION_ARGUMENT = "TestAutomationServiceInterfaceDescription";

    /**
     * Format of the timestamp values.
     */
    public static final String TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss";

    /**
     * Format of the calendar dates.
     */
    public static final String DATE_FORMAT = "dd.MM.yyyy";

    /**
     * Format of the hour values.
     */
    public static final String HOUR_FORMAT = "HH:mm";

    /**
     * Current release version of the test automation components.
     */
    public static final String TEST_AUTOMATION_SERVICE_INTERFACE_RELEASE_VERSION = "1.0.0";
}
