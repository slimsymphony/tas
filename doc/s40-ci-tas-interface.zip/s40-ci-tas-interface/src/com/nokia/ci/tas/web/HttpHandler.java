package com.nokia.ci.tas.web;

import java.io.OutputStream;
import java.io.PrintWriter;

import java.net.Socket;

import java.util.concurrent.ConcurrentLinkedQueue;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * Handles and dispatches all the HTTP messages received by the instance of Testing Automation Service.
 */
public class HttpHandler extends Thread {
    /**
     * Key token for getting test farm's products.
     */
    public static final String PRODUCTS_TOKEN = "products";

    /**
     * A pool of requests issued to this HTTP handler.
     */
    private ConcurrentLinkedQueue<HttpRequest> requests;

    /**
     * Variable which keeps handler running.
     */
    private boolean isRunning = true;

    /**
     * Current instance of the Test Automation Service Interface.
     */
    private TestAutomationServiceInterface testAutomationServiceInterface;

    /**
     * Current status of the Test Automation Service Interface instance.
     */
    private String status = "";
    
    /**
     * Description of all products handled by the Test Automation Service Interface.
     */
    private String productDescriptions = "";

    /**
     * The last time status was updated.
     */
    private long lastTimeStatusChecked = 0L;

    /**
     * The standard sequence of characters to end lines in HTTP headers.
     */
    private static final String CRLF = "\r\n";

    /**
     * Instance of the Test Automation Service Interface's global logger.
     */
    private Logger logger = Logger.getLogger(TestAutomationServiceInterface.GLOBAL_LOGGER_NAME);

    /**
     * Default constructor.
     *
     * @param testAutomationServiceInterface Instance of running Test Automation Service Interface
     */
    public HttpHandler(TestAutomationServiceInterface testAutomationServiceInterface) {

        super(); // Start as anonymous thread

        this.testAutomationServiceInterface = testAutomationServiceInterface;

        requests = new ConcurrentLinkedQueue();

        try {
            status = testAutomationServiceInterface.getCurrentStatus();
            productDescriptions = testAutomationServiceInterface.getProductDescriptions();
            lastTimeStatusChecked = System.currentTimeMillis();
        } catch (Exception e) {
            // Ignore
        }

        lastTimeStatusChecked = System.currentTimeMillis();

        setPriority(Thread.MAX_PRIORITY);
    }

    /**
     * Receiver's main routine.
     */
    @Override
    public void run() {
        p("Started working");
        
        while (isRunning) {
            try {
                if (!requests.isEmpty()) {
                    HttpRequest httpRequest = requests.poll();
                    
                    Socket connection = null;
                    String request = null;

                    if (httpRequest != null) {
                        connection = httpRequest.getConnection();
                        request = httpRequest.getRequest();
                    }
                    
                    OutputStream outputStream = null;

                    if (connection != null) {
                        String response = "";

                        if (request != null) {
                            p("Handling request " + request + " from " + connection.getInetAddress().getHostName() + ":" + connection.getPort());

                            if (request.contains(PRODUCTS_TOKEN)) {
                                try {
                                    response = productDescriptions;
                                } catch (Exception e) {
                                    p("Got troubles during processing incoming connection from " + connection.getInetAddress() + ": " + e.getClass() + " - " + e.getMessage());
                                }
                            } else {
                                response = status;
                            }
                        } else {
                            p("Handling invalid request " + request + " from " + connection.getInetAddress());
                            // Simply put a default status
                            response = status;
                        }

                        // Send response back and close connection
                        try {
                            outputStream = connection.getOutputStream();
                            PrintWriter output = new PrintWriter(outputStream);

                            output.print("HTTP/1.1 200 OK" + CRLF);
                            output.print("Content-Type: text/html; charset=UTF-8" + CRLF);
                            output.print("Content-Length: " + response.getBytes("UTF-8").length + CRLF);
                            output.print(CRLF);
                            output.print(response + CRLF + CRLF);
                            output.flush();

                            // Don't close connections, input or output streams here immediately, since HTTP 1.1 is using pervasive connections
                            sleep(Constant.DECISECOND);

                        } catch (Exception e) {
                            p("Got troubles during processing incoming connection from " + connection.getInetAddress().getHostName() + ":" + connection.getPort()
                                + " (" + connection.getInetAddress().getHostAddress() + ":" + connection.getPort() + ") - "
                                + e.getClass() + " - " + e.getMessage());
                            e.printStackTrace();
                        } finally {
                            // Always ensure that output stream is closed
                            if (outputStream != null) {
                                try {
                                    outputStream.close();
                                } catch (Exception e) {
                                    p("Got troubles while tried to close output stream from "
                                        + connection.getInetAddress().getHostName() + ":" + connection.getPort()
                                        + " - " + e.getClass() + " " + e.getMessage());
                                }
                            }

                            // Always ensure that connection is closed
                            if (connection != null) {
                                try {
                                    connection.close();
                                } catch (Exception e) {
                                    p("Got troubles while tried to close a connection from "
                                        + connection.getInetAddress().getHostName() + ":" + connection.getPort()
                                        + " - " + e.getClass() + " - " + e.getMessage());
                                }
                            }
                        }
                    }

                    // Always perform cleanups, no matter what has happened before

                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (Exception e) {
                            p("Got troubles during closing output stream from connection " + connection.getInetAddress().getHostName() + ":" + connection.getPort()
                                + " (" + connection.getInetAddress().getHostAddress() + ":" + connection.getPort() + ") - "
                                + e.getClass() + " - " + e.getMessage());
                            e.printStackTrace();
                        }
                    }

                    if (connection != null) {
                        try {
                            connection.close();
                            p("Successfully closed connection from " + connection.getInetAddress().getHostName() + ":" + connection.getPort()
                                + " (" + connection.getInetAddress().getHostAddress() + ":" + connection.getPort() + ")");
                        } catch (Exception e) {
                            p("Got troubles during closing connection from " + connection.getInetAddress().getHostName() + ":" + connection.getPort()
                                + " (" + connection.getInetAddress().getHostAddress() + ":" + connection.getPort() + ") - "
                                + e.getClass() + " - " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                }

                // Update main status each 15 seconds
                if ((System.currentTimeMillis() - lastTimeStatusChecked) > Constant.FIFTEEN_SECONDS) {
                    try {
                        status = testAutomationServiceInterface.getCurrentStatus();
                        productDescriptions = testAutomationServiceInterface.getProductDescriptions();
                    } catch (Exception e) {
                        p("Got troubles during extracting current status of the Test Automation Service Interface: " + e.getClass() + " - " + e.getMessage());
                    }

                    // Don't overload Test Automation Service Interface in any case
                    lastTimeStatusChecked = System.currentTimeMillis();
                }

                sleep(Constant.MILLISECOND); // Wait for any updates
            }
            catch (InterruptedException e) {
                p("HTTP handler was interrupted, stop working");
                p("Closing all available incoming connections");

                for (HttpRequest request : requests) {
                    Socket connection = request.getConnection();

                    if (connection != null) {
                        try {
                            connection.close();
                        } catch (Exception ioe) {
                            // Ignore
                        }
                    }
                }

                requests.clear();

                isRunning = false;
            }
        }
    }

    /**
     * Puts specified socket into connection pool.
     *
     * @param socket Connection to be processed
     * @param request HTTP request to be processed
     */
    public synchronized void handle(Socket socket, String request) {
        requests.add(new HttpRequest(socket, request));
        notify();
    }

    /**
     * Stops handler running.
     */
    public synchronized void stopWorking() {
        isRunning = false;
    }

    /**
     * Print specified text on debugging output stream.
     *
     * @param text A text to be printed on debugging output stream
     */
    private synchronized void p(String text) {
        logger.log(Level.ALL, "HTTP Handler: " + text);
    }
}
