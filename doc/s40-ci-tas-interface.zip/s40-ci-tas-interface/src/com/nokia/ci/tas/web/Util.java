package com.nokia.ci.tas.web;

import java.util.concurrent.TimeUnit;

/**
 * Contains various utility methods used in Test Automation Service Interface components.
 */
public class Util {
    /**
     * Converts specified time in milliseconds into a nice string containing days, hours, minutes and seconds.
     *
     * @param milliseconds Time value to be converted
     * @return String containing days, hours, minutes and seconds from specified milliseconds value
     */
    public static String convert(long milliseconds) {

        String result = "";

        if (milliseconds < Constant.ONE_SECOND) {
            if (milliseconds > 1L) {
                result = milliseconds + " milliseconds";
            } else {
                result = milliseconds + " millisecond";
            }

            return result;
        }

        long seconds = TimeUnit.MILLISECONDS.toSeconds(milliseconds);
        long dSeconds = seconds % 60L;

        if (dSeconds > 0L) {
            if (dSeconds > 1L) {
                result = dSeconds + " seconds";
            } else {
                result = dSeconds + " second";
            }

            seconds -= dSeconds;
        }

        long minutes = seconds / 60L;
        long dMinutes = minutes % 60L;

        if (dMinutes > 0L) {
            if (dMinutes > 1L) {
                result = dMinutes + " minutes " + result;
            } else {
                result = dMinutes + " minute " + result;
            }

            minutes -= dMinutes;
        }

        long hours = minutes / 60L;
        long dHours = hours % 24L;

        if (dHours > 0L) {
            if (dHours > 1L) {
                result = dHours + " hours " + result;
            } else {
                result = dHours + " hour " + result;
            }

            hours -= dHours;
        }

        long days = hours / 24L;

        if (days > 0L) {
            if (days > 1L) {
                result = days + " days " + result;
            } else {
                result = days + " day " + result;
            }
        }

        return result.trim();
    }
}
