package com.nokia.ci.tas.web;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;

import java.util.ArrayList;
import java.util.List;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * Configuration handler for Test Automation Service Interface.
 */
public class Configuration extends Thread {

    /**
     * Name of the configuration file.
     */
    private static final String NAME_OF_CONFIGURATION_FILE = "configuration.dat";

    /**
     * Parameter name for storing the checking period of Test Automation Service Instances in configuration file.
     */
    private static final String TEST_AUTOMATION_SERVICE_INSTANCES_CHECKING_PERIOD = "test-automation-service-instances-checking-period";

    /**
     * Test Automation Service Instances checking period in milliseconds.
     */
    private long testAutomationServiceInstancesCheckingPeriod = Constant.FIVE_MINUTES;
    
    /**
     * Parameter name for storing the address of Test Automation Service in configuration file.
     */
    private static final String TEST_AUTOMATION_SERVICE_ADDRESS = "test-automation-service-address";

    /**
     * Variable which keeps receiver running.
     */
    private boolean isRunning = true;

    /**
     * A reference to the configuration file.
     */
    private File configurationFile;
    
    /**
     * List of TAS addresses specified for discovery.
     */
    private List<String> tasAddresses = new ArrayList<String>(0);

    /**
     * Instance of the Test Automation Service Interface's global logger.
     */
    private Logger logger = Logger.getLogger(TestAutomationServiceInterface.GLOBAL_LOGGER_NAME);

    /**
     * Constructor.
     */
    public Configuration() {
        super(); // Start as anonymous thread
    }

    /**
     * Returns period of time for checking instances of the Test Automation Services.
     * 
     * @return Period of time for checking instances of the Test Automation Services
     */
    public long getTestAutomationServiceInstancesCheckingPeriod() {
        return testAutomationServiceInstancesCheckingPeriod;
    }

    /**
     * Returns a list with TAS addresses specified for discovery.
     * 
     * @return A list with TAS addresses specified for discovery
     */
    public List<String> getTASAddresses() {
        return tasAddresses;
    }

    /**
     * Configurator's main routine.
     */
    @Override
    public void run() {
        p("Started working");

        // Try to discover configuration file
        try {
            configurationFile = new File(NAME_OF_CONFIGURATION_FILE);

            if (!configurationFile.exists()) {
                if (configurationFile.createNewFile()) {
                    p("A new configuraiton file was created at " + configurationFile.getAbsolutePath());
                    // Store current configurations
                    try {
                        PrintWriter defaultConfiguration = new PrintWriter(configurationFile);
                        defaultConfiguration.append("");

                        // Add default parameters
                        defaultConfiguration.append("# All configuration settings supported by the Test Automation Service Interface\n\n");
                        defaultConfiguration.append("# Test Automation Service instances checking period in milliseconds (" + Util.convert(testAutomationServiceInstancesCheckingPeriod) + " by default, or " + testAutomationServiceInstancesCheckingPeriod + ")\n");
                        defaultConfiguration.append(TEST_AUTOMATION_SERVICE_INSTANCES_CHECKING_PERIOD + "=" + testAutomationServiceInstancesCheckingPeriod + "\n\n");

                        defaultConfiguration.append("# Test Automation Service address\n");
                        defaultConfiguration.append(TEST_AUTOMATION_SERVICE_ADDRESS + "=http://some-tas-address.nokia.com:12345\n\n");

                        defaultConfiguration.flush();
                        defaultConfiguration.close();

                        p("Configuration file is updated at " + configurationFile.getAbsolutePath());

                    } catch (Exception e) {
                        p("Warning: Got some troubles while tried to init configuration file at " + configurationFile.getAbsolutePath());
                        e.printStackTrace();
                    }
                } else {
                    p("Warning: Couldn't init configuration file at " + configurationFile.getAbsolutePath());
                }
            } else {
                p("Configuraiton file already exists at " + configurationFile.getAbsolutePath());
            }
        } catch (Exception e) {
            p("Got troubles while tried to init configuration file: " + e.getClass() + " - " + e.getMessage());
            e.printStackTrace();
        }

        while (isRunning) {
            BufferedReader reader = null;

            try {
                p("Checking configuration file...");

                reader = new BufferedReader(new FileReader(configurationFile));

                String line = null;
                List<String> extractedTASAddresses = new ArrayList<String>(0);

                while ((line = reader.readLine()) != null) {
                    line = line.trim();

                    if (!line.isEmpty() && !line.startsWith("#")) {
                        if (line.startsWith(TEST_AUTOMATION_SERVICE_INSTANCES_CHECKING_PERIOD)) {

                            testAutomationServiceInstancesCheckingPeriod = parse(line, testAutomationServiceInstancesCheckingPeriod);
                            p("Test Automation Service Instances checking period is " + Util.convert(testAutomationServiceInstancesCheckingPeriod));

                        } else if (line.startsWith(TEST_AUTOMATION_SERVICE_ADDRESS)) {
                            try {
                                // Parameter name is always separated from its value with the equality sign
                                if (line.indexOf("=") != -1) {
                                    String tasAddress = line.substring(line.indexOf("=") + 1).trim();

                                    if (!tasAddress.isEmpty()) {
                                        // Check if this value is already on the list
                                        if (!extractedTASAddresses.contains(tasAddress)) {
                                            extractedTASAddresses.add(tasAddress);
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                // Ignore
                            }
                        } else {
                            p("Got unsupported parameter line: " + line);
                        }
                    }
                }
                
                // Always make a copy
                tasAddresses = new ArrayList<String>(extractedTASAddresses);

                reader.close();

            } catch (Exception e) {
                p("Got troubles during its work: " + e.getClass() + " - " + e.getMessage() + " - " + e.toString());
                e.printStackTrace();
            } finally {
                // Try to close reader by all means
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (Exception e) {
                    p("Got troubles while tried to close configuration file reader: " + e.getClass() + " - " + e.getMessage() + " - " + e.toString());
                    e.printStackTrace();
                }
            }

            // No matter what has happened, go to sleep for about five minutes
            try {
                sleep(Constant.FIVE_MINUTES + 23456L);
            } catch (Exception e) {
                p("Got interrupted during sleep time: " + e.getClass() + " - " + e.getMessage() + " - " + e.toString());
                e.printStackTrace();
            }
        }
    }

    /**
     * Studies provided input line for a long value and extracts it.
     * Returns new parsed value if it was different from the specified old one, or old value otherwise.
     *
     * @param line Input text
     * @param old Old long value
     * @return New parsed value if it was different from the specified old one, or old value otherwise
     */
    private long parse(String line, long old) {
        long result = old;

        try {
            // Parameter name is always separated from its value with the equality sign
            if (line.indexOf("=") != -1) {
                String parsedValue = line.substring(line.indexOf("=") + 1).trim();

                if (!parsedValue.isEmpty()) {
                    long parsedLong = Long.parseLong(parsedValue);

                    if (parsedLong >= 0L) {
                        if (parsedLong != old) {
                            result = parsedLong;
                        }
                    }
                }
            }
        } catch (Exception e) {
            // Ignore
        }

        return result;
    }

    /**
     * Shutdowns configuration handler.
     */
    protected synchronized void shutdown() {
        p("Got a request to shutdown. Stop working...");
        isRunning = false;
        interrupt();
    }

    /**
     * Print specified text on debugging output stream.
     *
     * @param text A text to be printed on debugging output stream
     */
    private synchronized void p(String text) {
        logger.log(Level.ALL, "Configuration: " + text);
    }
}
