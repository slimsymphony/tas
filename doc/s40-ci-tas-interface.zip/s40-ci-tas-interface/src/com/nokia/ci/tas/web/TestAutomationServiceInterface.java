package com.nokia.ci.tas.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

import java.net.BindException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.URL;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Calendar;
import java.util.Timer;

import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Test Automation Service Interface.
 */
public class TestAutomationServiceInterface extends Thread {

    /**
     * Singleton instance of the Test Automation Service Interface.
     */
    private static TestAutomationServiceInterface self;

    /**
     * Name of the host where Test Automation Service Interface is running.
     */
    private String serviceHostname;

    /**
     * Port number that Test Automation Service Interface is using for listening incoming messages.
     */
    private int servicePort = -1;

    /**
     * Description of this Test Automation Service Interface instance, if specified.
     */
    private String description = "";

    /**
     * Variable which keeps Test Automation Service Interface running.
     */
    private boolean isRunning = true;

    /**
     * Variable which remembers the start time for this Test Automation Service Interface instance.
     */
    private long startTime = 0L;

    /**
     * Handler of all incoming messages.
     */
    private Receiver receiver;

    /**
     * Configuration handler.
     */
    private Configuration configuration;

    /**
     * Date and time format used for timestamps in logging prints.
     */
    private SimpleDateFormat timestampFormat;

    /**
     * Date format used in various locations.
     */
    private SimpleDateFormat dateFormat;

    /**
     * Hour format used in various locations.
     */
    private SimpleDateFormat hourFormat;

    /**
     * Name of the directory where Test Automation Service Interface keeps all log files.
     */
    private static final String SERVICE_LOGS_DIRECTORY = "logs";

    /**
     * Reference to a logs directory used by Test Automation Service Interface.
     */
    private File logsDirectory;

    /**
     * Format used in names of the log files. Here they follow the Java standard date and time patterns.
     */
    private String logFilenameFormat = "yyyy-MM-dd";

    /**
     * Name of the directory where Test Automation Service Interface keeps all its maintenance messages.
     */
    private static final String SERVICE_MESSAGES_DIRECTORY = "messages";

    /**
     * Reference to a messages directory used by Test Automation Service Interface.
     */
    private File messagesDirectory;

    /**
     * Timer used for switching log files.
     */
    private Timer timer;

    /**
     * Keeps a copy of web-page representing current status of the Test Automation Service Interface.
     */
    private String currentStatus = "Loading...";

    /**
     * Keeps a copy of descriptions for all products discoverd by the Test Automation Service Interface.
     */
    private StringBuffer productDescriptions;

    /**
     * Period of time between checks of Test Automation Service Instances.
     */
    private long testAutomationServiceInstancesCheckingPeriod = Constant.FIVE_MINUTES;
    
    /**
     * Moment of the time when the last discovery of TASes was perfomed.
     */
    private long timeOfLastDiscovery = 0L;
    
    /**
     * A list of TAS addresses specified for discovery.
     */
    private List<String> tasAddresses;
    
    /**
     * Current states of the corresponding TAS instances.
     */
    private List<String> tasStates;

    /**
     * Name associated with the global Logger.
     */
    public static final String GLOBAL_LOGGER_NAME = "TestAutomationServiceInterface";

    /**
     * Global logger used in all prints and messaging.
     */
    private static Logger logger;

    /**
     * Creates an instance of the Test Automation Service Interface.
     * The constructor is made private for allowing
     * only the single static instance of the service on a hosting machine.
     *
     * @param port A port number on which this instance of Test Automation Service Interface should be launched
     */
    private TestAutomationServiceInterface(int port) {
        super(); // Start as anonymous thread

        // Remember the moment when this instance was created
        startTime = System.currentTimeMillis();

        // Create a date and time formatter
        timestampFormat = new SimpleDateFormat(Constant.TIMESTAMP_FORMAT);
        dateFormat = new SimpleDateFormat(Constant.DATE_FORMAT);
        hourFormat = new SimpleDateFormat(Constant.HOUR_FORMAT);
        
        tasAddresses = new ArrayList<String>(0);
        tasStates = new ArrayList<String>(0);
        productDescriptions = new StringBuffer("");

        // Init logging
        try {
            logger = Logger.getLogger(GLOBAL_LOGGER_NAME);
            logger.setLevel(Level.ALL);

            // Create and append console formatter
            ConsoleFormatter consoleFormatter = new ConsoleFormatter();

            ConsoleHandler consoleHandler = new ConsoleHandler();
            consoleHandler.setLevel(Level.ALL);
            consoleHandler.setFormatter(consoleFormatter);
            logger.addHandler(consoleHandler);

            // Create and append log file formatter
            logsDirectory = new File(SERVICE_LOGS_DIRECTORY);
            if (!logsDirectory.exists()) {
                if (logsDirectory.mkdirs()) {
                    p("Test Automation Service Interface's log directory was successfully created at " + logsDirectory.getAbsolutePath());
                }
            } else {
                p("Test Automation Service Interface's log directory was successfully initialized at " + logsDirectory.getAbsolutePath());
            }

            // Create formatter for the log file
            LogFileFormatter logFileFormatter = new LogFileFormatter(new SimpleDateFormat(Constant.TIMESTAMP_FORMAT));

            // Create timer and init current log
            timer = new Timer(true);
            timer.schedule(new LogFileSwitcher(GLOBAL_LOGGER_NAME, logsDirectory, logFileFormatter, logFilenameFormat, LogFileSwitcher.NO_CLEANUP), new Date());

            // Schedule changes of log files each 24 hours
            Calendar calendar = Calendar.getInstance();

            // Enable log file changes right at the next day's 00:00:00.000
            calendar.set(Calendar.HOUR_OF_DAY, calendar.getMinimum(Calendar.HOUR_OF_DAY));
            calendar.set(Calendar.MINUTE, calendar.getMinimum(Calendar.MINUTE));
            calendar.set(Calendar.SECOND, calendar.getMinimum(Calendar.SECOND));
            calendar.set(Calendar.MILLISECOND, calendar.getMinimum(Calendar.MILLISECOND));
            calendar.add(Calendar.DATE, 1);

            Date nextLogChangeDate = calendar.getTime();

            // Schedule timer to switch log files each 24 hours
            timer.scheduleAtFixedRate(new LogFileSwitcher(GLOBAL_LOGGER_NAME, logsDirectory, logFileFormatter, logFilenameFormat, LogFileSwitcher.NO_CLEANUP), nextLogChangeDate, 24L * Constant.ONE_HOUR);

            p("Log file's switcher was successfully scheduled");

        } catch (Exception e) {
            p("Got troubles while tried to initialize logging:" + e.toString());
            e.printStackTrace();
            return;
        }

        // Init configuration handler
        try {
            configuration = new Configuration();
            configuration.start();
        } catch (Exception e) {
            p("Got troubles while tried to initialize configuration handler:" + e.toString());
            e.printStackTrace();
            return;
        }

        // Init messages directory
        try {
            messagesDirectory = new File(SERVICE_MESSAGES_DIRECTORY);

            if (!messagesDirectory.exists()) {
                if (messagesDirectory.mkdirs()) {
                    p("Test Automation Service Interface's messages directory was successfully created at " + messagesDirectory.getAbsolutePath());
                }
            } else {
                p("Test Automation Service Interface's messages directory was successfully initialized at " + messagesDirectory.getAbsolutePath());
            }

        } catch (Exception e) {
            p("Got troubles while tried to initialize messages directory: " + e.toString());
            e.printStackTrace();
            return;
        }

        p("Launching Test Automation Service Interface v" + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_RELEASE_VERSION);

        // Set the port number
        if (port < 0 || port > 0xFFFF) {
            servicePort = Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DEFAULT_PORT_NUMBER;
            p("Provided port number " + port + " is out of valid ranges. Launching Test Automation Service Interface on default port number " + servicePort);
        } else {
            servicePort = port;
            p("Launching Test Automation Service Interface on port number " + servicePort);
        }

        // Get the hostname
        if (serviceHostname == null || serviceHostname.isEmpty()) {
            p("Trying to get the hostname of Test Automation Service Interface");

            try {
                serviceHostname = InetAddress.getLocalHost().getCanonicalHostName();
                p("Extracted hostname is " + serviceHostname);
            } catch (Exception e) {
                p("Got troubles while trying to extract local hostname: " + e.getClass() + " - " + e.getMessage());
                p("Will try to extract hostname from the environment variables");

                serviceHostname = (String) System.getenv().get("HOST"); // By default we are running on Linux

                p("HOST environment variable returned " + serviceHostname);

                if (serviceHostname == null || serviceHostname.isEmpty()) {
                    serviceHostname = (String) System.getenv().get("HOSTNAME"); // Try another Linux environment variable
                    p("HOSTNAME environment variable returned " + serviceHostname);
                }

                if (serviceHostname == null || serviceHostname.isEmpty()) {
                    serviceHostname = (String) System.getenv().get("COMPUTERNAME"); // Otherwise we are probably running on Windows
                    p("COMPUTERNAME environment variable returned " + serviceHostname);
                }

                if (serviceHostname == null || serviceHostname.isEmpty()) {
                    p("Warning: Couldn't extract a hostname for the Test Automation Service Interface out of environment variables. Please specify one either in HOST, HOSTNAME or in COMPUTERNAME system variables.");
                    serviceHostname = "localhost";
                }
            }
        }

        p("Trying to launch Test Automation Service Interface on " + serviceHostname + ":" + servicePort);

        setPriority(Thread.MAX_PRIORITY);
    }

    /**
     * Returns an instance of the Test Automation Service Interface which runs on current hostname and on specified port
     * or creates one on specified port if it was not yet created.
     *
     * @param port Port number that an instance of Test Automation Service Interface should use
     * @param description Optional description specified for this instance of Test Automation Service Interface
     * @return A singleton instance of the Test Automation Service Interface
     */
    public synchronized static TestAutomationServiceInterface getInstance(int port, String description) {

        if (self == null) {
            self = new TestAutomationServiceInterface(port);
            self.setDescription(description);
            self.start();
        }

        return self;
    }

    /**
     * Main routine of the Test Automation Service Interface.
     */
    @Override
    public void run() {
        // Create server socket and launch receiver
        try {
            ServerSocket listener = new ServerSocket(servicePort);

            p("Testing Automation Service Interface started working on hostname " + serviceHostname + " and port " + servicePort);
            
            // Create and start Receiver which will handle all incoming connections
            receiver = new Receiver(self, listener);
            receiver.start();

            // Enter into the main loop
            while (isRunning) {
                // Try to discover TASes each minute
                if ((System.currentTimeMillis() - timeOfLastDiscovery) > testAutomationServiceInstancesCheckingPeriod) {
                    discoverTASInstances();
                    timeOfLastDiscovery = System.currentTimeMillis();
                    updateCurrentStatus();
                }

                sleep(Constant.DECISECOND); // Wait for any updates
            }
        } catch (Exception e) {
            if (e instanceof BindException) {
                p("Cannot start Test Automation Service Interface on hostname " + serviceHostname + " and port " + servicePort + " because of already occupied port number.");
                p("Please try to launch Test Automation Service Interface on another port or shutdown already running instance of Test Automation Service Interface on this hostname and required port number.");
            } else {
                p("Couldn't run Test Automation Service Interface on hostname " + serviceHostname + " and port " + servicePort + " because of: " + e.getMessage());
                e.printStackTrace();
            }

            if (receiver != null) {
                receiver.stopWorking();
            }

            isRunning = false;
        }
    }

    /**
     * Return hostname associated with current instance of service.
     *
     * @return Hostname associated with current instance of service
     */
    public String getHostname() {
        return serviceHostname;
    }

    /**
     * Return port number associated with current instance of service.
     *
     * @return Port number associated with current instance of service
     */
    public int getPort() {
        return servicePort;
    }

    /**
     * Returns a hostname and port of Test Automation Service Interface 
     * in canonical form "hostname:port".
     *
     * @return A hostname and port of Test Automation Service Interface in canonical form "hostname:port"
     */
    public String getHostnameAndPort() {
        return serviceHostname + ":" + servicePort;
    }

    /**
     * Sets optional description for this instance of Test Automation Service Interface.
     *
     * @param description Optional description for this instance of Test Automation Service Interface
     */
    private void setDescription(String description) {
        if (description != null && !description.isEmpty()) {
            this.description = description;
        }
    }

    /**
     * Returns a description specified for this instance of Test Automation Service Interface.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns current configuration for the Test Automation Service Interface.
     *
     * @return Current configuration for the Test Automation Service Interface
     */
    public Configuration getConfiguration() {
        return configuration;
    }

    /**
     * Returns current status of the whole Test Automation Service Interface in textual form.
     *
     * @return Current status of the whole Test Automation Service Interface in textual form
     */
    protected String getCurrentStatus() {
        return currentStatus;
    }

    /**
     * Returns JSON descriptions of all products handled by this instance of Test Automation Service Interface.
     *
     * @return JSON descriptions of all products handled by this instance of Test Automation Service Interface
     */
    protected String getProductDescriptions() {
        return productDescriptions.toString();
    }
    
    /**
     * 
     */
    protected void discoverTASInstances() {
        if (configuration != null) {
            // Update settings from configuration
            testAutomationServiceInstancesCheckingPeriod = configuration.getTestAutomationServiceInstancesCheckingPeriod();
            // Always perform a copy of tas instances from the configuration to avoid concurrency troubles
            tasAddresses = new ArrayList<String>(configuration.getTASAddresses());
            tasStates = new ArrayList<String>(0);
            StringBuffer descriptions = new StringBuffer();
            
            if (!tasAddresses.isEmpty()) {
                for (String tasAddress : tasAddresses) {
                    p("Performing a check of TAS " + tasAddress + " ...");
                    String tasState = "";

                    try {
                        if (!tasAddress.isEmpty()) {
                            if (!tasAddress.endsWith("/products")) {
                                tasAddress += "/products";
                            }
                        }
                        
                        p("Issuing HTTP GET request to the TAS address " + tasAddress + " ...");
                        
                        try {
                            URL url = new URL(tasAddress);
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                            connection.setRequestMethod("GET");
                            connection.setRequestProperty("Accept", "application/json");

                            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                                p("Got HTTP troubles while tried to interact with TAS at " + tasAddress + ", HTTP error code: " + connection.getResponseCode());
                                tasState += " - Last check <font color=\"#ee0000\">FAILED</font> due to HTTP response code " + connection.getResponseCode();
                            } else {
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader((connection.getInputStream())));

                                String line;
                                StringBuffer output = new StringBuffer();

                                while ((line = bufferedReader.readLine()) != null) {
                                    // This is done to avoid any troubles
                                    if (!line.contains("<!DOCTYPE html>")) {
                                        if (line.contains("{ \"products\": [")) {
                                            //p("Ignored line: " + line);
                                        } else if (line.contains("] }")) {
                                            //p("Ignored line: " + line);
                                        } else {
                                            output.append(line + "\n");
                                        }
                                    } else {
                                        break;
                                    }
                                }
                                
                                String trimmedOutput = output.toString().trim();

                                if (!trimmedOutput.isEmpty()) {
                                    if (trimmedOutput.endsWith(",")) {
                                        descriptions.append(trimmedOutput);
                                    } else {
                                        descriptions.append(trimmedOutput);
                                        descriptions.append("\n,");
                                    }
                                }
                                
                                tasState += " - <font color=\"#006600\">OK</font>";

                                p("Check to the TAS address " + tasAddress + " was successful");
                                
                                //p("Descriptions so far:\n'" + descriptions.toString() + "'\n");
                            }

                            connection.disconnect();

                        } catch (Exception e) {
                            p("Got troubles while tried to interact with TAS at " + tasAddress + ": " + e.getClass() + " - " + e.getMessage());
                            tasState += " - Last check <font color=\"#ee0000\">FAILED</font> due to " + e.getClass() + " - " + e.getMessage();
                        }
                        
                    } catch (Exception e) {
                        p("Got troubles while tried to interact with TAS at " + tasAddress + ": " + e.getClass() + " - " + e.getMessage());
                        tasState += " - Last check <font color=\"#ee0000\">FAILED</font> due to " + e.getClass() + " - " + e.getMessage();
                    }

                    tasStates.add(tasState);
                }
                
                // Remove the last colon
                String productElements = descriptions.toString().trim();

                //p("final descriptions:\n'" + productElements + "'\n");

                if (productElements.endsWith(",")) {
                    productElements = new String(productElements.substring(0, productElements.lastIndexOf(",")));
                    //p("product elements:\n'" + productElements + "'\n");
                }
                
                // Put product descriptions into JSON array
                descriptions = new StringBuffer();
                descriptions.append("{\n");
                descriptions.append("\"products\": [\n");
                descriptions.append(productElements + "\n");
                descriptions.append("]\n");
                descriptions.append("\n}\n");

                // Store results
                productDescriptions = descriptions;
                
                //p("Final result:\n'" + productDescriptions + "'\n");
            }
        }
    }

    /**
     * Updates current status of this Test Automation Service Interface.
     */
    protected void updateCurrentStatus() {
        try {
            StringBuffer status = new StringBuffer();

            status.append("<!DOCTYPE html>\n");
            status.append("<html>\n");
            status.append("<head>\n");
            status.append("<title>");
            status.append("Test Automation Service Interface " + serviceHostname + ":" + servicePort);
            if (!description.isEmpty()) {
                status.append(" - " + description);
            }
            status.append("</title>\n");
            status.append("<link rel=\"shortcut icon\" href=\"http://wikis.in.nokia.com/pub/CI20Development/TASGuide/favicon.ico\" type=\"image/x-icon\" />\n");
            status.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n");
            status.append("<script type=\"text/javascript\">\n");
            status.append("    function toggle(testId) {\n");
            status.append("        var element = document.getElementById(testId);\n");
            status.append("        var text = document.getElementById(\"detailed \" + testId);\n");
            status.append("        if (element.style.display == \"block\") {\n");
            status.append("            element.style.display = \"none\";\n");
            status.append("            text.innerHTML = \"Show details\";\n");
            status.append("        } else {\n");
            status.append("            element.style.display = \"block\";\n");
            status.append("            text.innerHTML = \"Hide details\";\n");
            status.append("        }\n");
            status.append("    }\n");
            status.append("</script>\n");
            status.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n");
            status.append("</head>\n");
            status.append("<body>\n<table border=\"0\">\n\n");

            // Print out basic information about this Test Automation Service Interface
            status.append("<tr><td>Test Automation Service Interface v" + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_RELEASE_VERSION);

            if (!description.isEmpty()) {
                status.append(" for \"<b>" + description + "</b>\"");
            }

            status.append(", running on ");
            status.append(serviceHostname + ":" + servicePort);
            status.append(", status at " + timestampFormat.format(new Date(System.currentTimeMillis())));
            status.append(" (uptime " + Util.convert(System.currentTimeMillis() - startTime) + ")");
            status.append("</td></tr>\n\n");

            status.append("<tr><td>&nbsp;</td></tr>\n\n");

            // Show statistics
            status.append("<tr><td>List of the Test Automation Services tracked through this interface:</td></tr>\n\n");
            status.append("<tr><td>\n<blockquote>\n\n");
            
            if (tasAddresses != null) {
                if (!tasAddresses.isEmpty()) {
                    if (tasAddresses.size() != tasStates.size()) {
                        for (String tasAddress : tasAddresses) {
                            status.append("<a href=\"" + tasAddress + "\" target=_blank>" + tasAddress + "</a><br/><br/>\n");
                        }
                    } else {
                        for (int i = 0; i < tasAddresses.size(); i++) {
                            String tasAddress = tasAddresses.get(i);
                            String tasStatus = tasStates.get(i);

                            status.append("<a href=\"" + tasAddress + "\" target=_blank>" + tasAddress + "</a>" + tasStatus + "<br/><br/>\n");
                        }
                    }
                } else {
                    status.append("<font color=\"#ee0000\">No TAS addresses are specified, please check configurations</font><br/><br/>\n");
                }
            } else {
                status.append("<font color=\"#ee0000\">Couldn't obtain TAS addresses, please check configurations</font><br/><br/>\n");
            }

            status.append("\n</blockquote>\n</td></tr>\n\n");

            status.append("<tr><td>\n");
            status.append("The last discovery of Test Automation Service instances was done at " + timestampFormat.format(new Date(timeOfLastDiscovery)) + "<br/><br/>\n");
            status.append("</td></tr>\n\n");

            status.append("<tr><td>&nbsp;</td></tr>\n\n");

            status.append("\n</table>\n</body>\n</html>\n");

            currentStatus = status.toString();

        } catch (Exception e) {
            p("Got troubles with updating current status: " + e.getClass() + " - " + e.getMessage() + " - " + e.toString());
            e.printStackTrace();
        }
    }

    /**
     * Creates a new file in the messages directory and stores specified message in it.
     *
     * @param message Message text to be used
     */
    public void createMessage(String message) {
        if (message != null && !message.isEmpty()) {
            try {
                File messageFile = new File(messagesDirectory.getAbsolutePath() + System.getProperty("file.separator") + System.currentTimeMillis() + ".msg");
                messageFile.createNewFile();

                // Write message into craeted file
                if (messageFile != null && messageFile.exists()) {
                    FileOutputStream fileOutputStream = new FileOutputStream(messageFile);
                    fileOutputStream.write(message.getBytes());
                    fileOutputStream.flush();
                    fileOutputStream.close();
                }
            } catch (Exception e) {
                p("Got troubles while tried to create a file for message '" + message + "': " + e.toString());
                e.printStackTrace();
            }
        }
    }

    /**
     * Prints help message to console.
     */
    private static void printHelp() {
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("\nTest Automation Service Interface v" + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_RELEASE_VERSION + "\n");
        stringBuilder.append("\nThe default way to launch an instance of Test Automation Service Interface:\n\n");
        stringBuilder.append("java -jar TestAutomationServiceInterface.jar "
                + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_PORT_NUMBER_ARGUMENT + "=" + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DEFAULT_PORT_NUMBER + "\n\n");
        stringBuilder.append("Here the \"" + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_PORT_NUMBER_ARGUMENT
                + "\" parameter stands for a port number that Test Automation Service Interface will use for all incoming communications.");
        stringBuilder.append("\n\nTyping just \"java -jar TestAutomationServiceInterface.jar\" will automatically launch Test Automation Service Interface on its default port "
                + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DEFAULT_PORT_NUMBER + ". ");
        stringBuilder.append("\n\nPlease note that Test Automation Service Interface might be launched and used anywhere where at least the Java 6 runtime environment is presented.");
        stringBuilder.append("\n\nThe hostname of the machine (and so the Test Automation Service Interface) will be automatically extracted by Java. ");
        stringBuilder.append("However, if Java will fail on extracting the hostname of the machine, it will try to use the \"HOST\", \"HOSTNAME\" or \"COMPUTERNAME\" environment variables.\n");

        stringBuilder.append("\nLaunching Test Automation Service Interface with a description:\n\n");

        stringBuilder.append("java -jar TestAutomationServiceInterface.jar "
                + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_PORT_NUMBER_ARGUMENT + "=" + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DEFAULT_PORT_NUMBER
                + " " + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DESCRIPTION_ARGUMENT + "=\"Some description for this instance, if any\"\n\n");

        stringBuilder.append("Here the \"" + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DESCRIPTION_ARGUMENT
                + "\" parameter stands for a short description assigned to the Test Automation Service Interface instance.\n");

        System.out.println(stringBuilder.toString());
    }

    /**
     * Used for debug or informal message prints to console.
     *
     * @param text A message to be printed on console
     */
    private static void p(String text) {
        logger.log(Level.ALL, "TAS Interface: " + text);
    }

    /**
     * Launch Test Automation Service Interface as a standalone application
     *
     * @param arguments Startup arguments used for Test Automation Service Interface configuration
     */
    public static void main(String[] arguments) {

        int port = -1;
        String description = "";

        if (arguments.length > 0) {

            for (int i = 0; i < arguments.length; i++) {

                String parameter = arguments[i];

                if (parameter != null && !parameter.isEmpty()) {

                    // Check for the help request
                    if (parameter.indexOf("help") != -1 || parameter.indexOf("HELP") != -1) {

                        printHelp();

                        return; // Nothing else to do

                    } else if (parameter.indexOf(Constant.TEST_AUTOMATION_SERVICE_INTERFACE_PORT_NUMBER_ARGUMENT) != -1) {
                        try {
                            // Parse port number of the Test Automation Service Interface
                            port = Integer.parseInt(parameter.substring(parameter.indexOf("=") + 1));

                            if (port <= 0) {
                                System.out.println(Constant.TEST_AUTOMATION_SERVICE_INTERFACE_PORT_NUMBER_ARGUMENT + " parameter has invalid value " + port + ". Please specify a valid one or type command \"java -jar TestAutomationServiceInterface.jar -help\" for getting more information.");
                                return;
                            }
                        } catch (Exception e) {
                            System.out.println(Constant.TEST_AUTOMATION_SERVICE_INTERFACE_PORT_NUMBER_ARGUMENT + " parameter is probably incorrectly specified. Please type command \"java -jar TestAutomationServiceInterface.jar -help\" for getting more information.");
                            return;
                        }
                    } else if (parameter.indexOf(Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DESCRIPTION_ARGUMENT) != -1) {
                        try {
                            int index = parameter.indexOf("=");

                            if (index != -1) {
                                description = parameter.substring(index + 1);
                            }
                        } catch (Exception e) {
                            System.out.println(Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DESCRIPTION_ARGUMENT + " parameter is probably incorrectly specified. Please type command \"java -jar TestAutomationServiceInterface.jar -help\" for getting more information.");
                            return;
                        }
                    } else {
                        System.out.println("Specified parameter " + parameter + " is not supported and will be ignored.");
                    }
                }
            }
        } else {
            System.out.println("Port number for the Test Automation Service Interface was not specified. Default port number " + Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DEFAULT_PORT_NUMBER + " will be used.");
            port = Constant.TEST_AUTOMATION_SERVICE_INTERFACE_DEFAULT_PORT_NUMBER;
        }

        if (port > 0) {
            TestAutomationServiceInterface tas = getInstance(port, description);
        }
    }
}
